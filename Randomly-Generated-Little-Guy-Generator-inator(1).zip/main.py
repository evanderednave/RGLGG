#possibly insert ASCII art of RGLG
import random
from colorama import Fore
body_style = ["standing pose 1", "standing pose 2", "seated pose 1", "seated pose 2"]
arms = ["short", "long"]
antennae = ["no", "alien", "bug", "sprite", "axolotl"]
belly_style = ["have a panel", "have a pouch", "have a rib cage", "be ribbed"]

print("Welcome to the Randomly Generated Little Guy Generator-inator!")
print("What would you like your RGLG's main color to be?")
print('Choose from: red, orange, yellow, green, blue, violet, black,\nwhite, or brown.')
main_color = input()
print("And what accent color would you like?")
accent_color = input()
print('Great choices! Now it\'s time to generate your Little Guy!')
print('Here\'s what your RGLG will look like:')
print(f'Their body will be {Fore.RED}{random.choice(body_style)}{Fore.WHITE}.')
print(f'Their arms will be in {Fore.RED}{random.choice(arms)}{Fore.WHITE}.')
if random.choice(antennae) == "no":
  print(f'They will have {Fore.RED}no {Fore.WHITE}antennae.')
else:
  print(f'They will have {Fore.RED}{random.choice(antennae)}{Fore.WHITE} antennae.')
print(f'Their belly will {Fore.RED}{random.choice(belly_style)}{Fore.WHITE}.')

